/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import './ResultsAnalytics.css';

const CANDIDATES_AWAITING_REVIEW = [
    { 
        id: 2, 
        email: 'samantha.jones@example.com',
        interviewLog: [
            {
                question: "Can you walk me through your experience with React and state management libraries like Redux or MobX?",
                answer: "Sure. I've worked extensively with React for about five years now. In my previous role, I was the lead on a project where we used Redux for managing a very complex application state with lots of asynchronous actions. I'm very comfortable with writing actions, reducers, and using middleware like Redux Thunk. I've also dabbled with MobX on personal projects and appreciate its simplicity for smaller-scale apps.",
                videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            },
            {
                question: "Describe a challenging project you worked on. What was the problem, what was your role, and what was the outcome?",
                answer: "The most challenging project was a legacy code migration from Angular.js to React. I was responsible for planning the phased rollout to avoid disrupting users. The main problem was untangling years of coupled code. We successfully migrated the entire application over six months with zero downtime, which was a huge win.",
                videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
            }
        ]
    }
];

const AGGREGATE_DATA = {
    totalInterviews: 4,
    pendingReview: 1,
    approved: 1,
    averageScore: 89,
    scoreDistribution: [
        { range: '0-70%', count: 0, color: '#e57373' },
        { range: '71-85%', count: 1, color: '#ffc107' },
        { range: '86-95%', count: 2, color: '#A78BFA' },
        { range: '96-100%', count: 1, color: '#66bb6a' },
    ]
};

interface Evaluation {
    clarity: number;
    relevance: number;
    technicalAccuracy: number;
    completeness: number;
    overallScore: number;
    rationale: string;
}

const ScoreIndicator = ({ label, score }: { label: string, score: number }) => {
    const getScoreColorClass = (s: number) => {
        if (s <= 4) return 'low';
        if (s <= 7) return 'medium';
        return 'high';
    };

    const colorClass = getScoreColorClass(score);
    const widthPercentage = score * 10;

    return (
        <div className="score-indicator">
            <div className="score-label">
                <span>{label}</span>
                <strong>{score}/10</strong>
            </div>
            <div className="score-bar-container">
                <div className={`score-bar ${colorClass}`} style={{ width: `${widthPercentage}%` }}></div>
            </div>
        </div>
    );
};


export const ResultsAnalytics = () => {
    const [candidates, setCandidates] = useState(CANDIDATES_AWAITING_REVIEW);
    const [selectedCandidate, setSelectedCandidate] = useState(candidates.length > 0 ? candidates[0] : null);
    const [evaluation, setEvaluation] = useState<Evaluation | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [approvedCandidates, setApprovedCandidates] = useState<number[]>([]);

    const handleSelectCandidate = (candidate) => {
        setSelectedCandidate(candidate);
        setEvaluation(null); // Reset evaluation when switching candidates
        setError('');
    };

    const handleApprove = (candidateId) => {
        if (!approvedCandidates.includes(candidateId)) {
            setApprovedCandidates([...approvedCandidates, candidateId]);
        }
    };

    const handleEvaluate = async () => {
        if (!selectedCandidate) return;

        setIsLoading(true);
        setError('');
        setEvaluation(null);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

            const transcript = selectedCandidate.interviewLog.map((item, index) =>
                `Question ${index + 1}: ${item.question}\nAnswer ${index + 1}: ${item.answer}`
            ).join('\n\n');

            const prompt = `
                Analyze the following interview transcript for a 'Senior Frontend Developer' role.
                Provide a quantitative evaluation based on the candidate's responses.
                Score each category out of 10. The overall score should be a weighted average out of 100.
                Provide a brief rationale for your scoring.

                Transcript:
                ${transcript}
            `;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
                config: {
                    systemInstruction: "You are a senior technical hiring manager AI. Evaluate interview transcripts and provide scores and rationale in a structured JSON format.",
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            clarity: { type: Type.INTEGER, description: "Score for clarity and communication (1-10)." },
                            relevance: { type: Type.INTEGER, description: "Score for relevance of the answers to the questions (1-10)." },
                            technicalAccuracy: { type: Type.INTEGER, description: "Score for the technical accuracy of the answers (1-10)." },
                            completeness: { type: Type.INTEGER, description: "Score for the completeness and depth of the answers (1-10)." },
                            overallScore: { type: Type.INTEGER, description: "A final weighted score out of 100." },
                            rationale: { type: Type.STRING, description: "A brief summary explaining the scores." }
                        },
                        required: ["clarity", "relevance", "technicalAccuracy", "completeness", "overallScore", "rationale"]
                    }
                }
            });
            
            const jsonStr = response.text.trim();
            const result = JSON.parse(jsonStr);
            setEvaluation(result);

        } catch (e) {
            console.error(e);
            setError('Failed to get AI evaluation. The model may be overloaded. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const isApproved = selectedCandidate && approvedCandidates.includes(selectedCandidate.id);

    return (
        <div className="results-analytics-panel">
            <header className="page-header">
                <h2>Results & Analytics</h2>
                <p>Review candidate interviews and leverage AI for detailed performance evaluation.</p>
            </header>

            <section className="analytics-summary-section">
                <h3>Platform Analytics</h3>
                <div className="stats-grid">
                    <div className="stat-card">
                        <h4>Total Interviews</h4>
                        <p>{AGGREGATE_DATA.totalInterviews}</p>
                    </div>
                    <div className="stat-card">
                        <h4>Average Score</h4>
                        <p>{AGGREGATE_DATA.averageScore}%</p>
                    </div>
                    <div className="stat-card">
                        <h4>Pending Review</h4>
                        <p>{AGGREGATE_DATA.pendingReview}</p>
                    </div>
                    <div className="stat-card">
                        <h4>Approved</h4>
                        <p>{AGGREGATE_DATA.approved}</p>
                    </div>
                </div>
                 <div className="chart-container">
                  <h4>Candidate Score Distribution</h4>
                  <div className="bar-chart" role="figure" aria-label="A bar chart showing the distribution of candidate scores.">
                    {AGGREGATE_DATA.scoreDistribution.map((bar, index) => (
                        <div key={index} className="bar-wrapper" role="group" aria-label={`${bar.range}: ${bar.count} candidates`}>
                            <div className="bar-value" aria-hidden="true">{bar.count}</div>
                            <div className="bar" style={{ height: `${(bar.count / (Math.max(...AGGREGATE_DATA.scoreDistribution.map(d => d.count)) || 1)) * 100}%`, backgroundColor: bar.color }}></div>
                            <div className="bar-label" aria-hidden="true">{bar.range}</div>
                        </div>
                    ))}
                  </div>
                </div>
            </section>

            <section className="ra-section">
                <h3>Candidate Review Pipeline</h3>
                <div className="results-layout">
                    <aside className="candidate-list-sidebar">
                        <h3>Awaiting Review ({candidates.length})</h3>
                        {candidates.length > 0 ? (
                            <div role="radiogroup" aria-label="Select a candidate to review">
                                {candidates.map(candidate => (
                                    <button
                                        key={candidate.id}
                                        role="radio"
                                        aria-checked={selectedCandidate?.id === candidate.id}
                                        className={`candidate-entry ${selectedCandidate?.id === candidate.id ? 'active' : ''}`}
                                        onClick={() => handleSelectCandidate(candidate)}
                                    >
                                        {candidate.email}
                                    </button>
                                ))}
                            </div>
                        ) : (
                            <p className="no-candidates-message">No candidates are currently awaiting review.</p>
                        )}
                    </aside>

                    <main className="evaluation-content">
                        {selectedCandidate ? (
                            <>
                                <div className="evaluation-header">
                                    <h3>{selectedCandidate.email}</h3>
                                    {isApproved ? (
                                        <span className="approved-tag" role="status">Approved</span>
                                    ) : (
                                        <button 
                                            className="approve-button"
                                            onClick={() => handleApprove(selectedCandidate.id)}
                                            disabled={!evaluation}
                                            aria-label={!evaluation ? "Evaluate first to enable approval" : `Approve ${selectedCandidate.email}`}
                                        >
                                            Approve Candidate
                                        </button>
                                    )}
                                </div>
                                <div className="interview-log-container">
                                    {selectedCandidate.interviewLog.map((log, index) => (
                                        <div key={index} className="qa-card">
                                            <div className="question-section">
                                                <strong>Question {index + 1}:</strong>
                                                <p>{log.question}</p>
                                            </div>
                                            <div className="answer-video-container">
                                                <div className="answer-section">
                                                    <strong>Candidate's Answer:</strong>
                                                    <p>{log.answer}</p>
                                                </div>
                                                <div className="video-playback-container">
                                                    <strong>Recorded Video:</strong>
                                                    <video
                                                        src={log.videoUrl}
                                                        controls
                                                        className="video-player"
                                                        title={`Video response for question ${index + 1}`}
                                                    >
                                                        Your browser does not support the video tag.
                                                    </video>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="evaluation-section">
                                    <button onClick={handleEvaluate} disabled={isLoading} className="evaluate-button">
                                        {isLoading && <span className="spinner"></span>}
                                        {isLoading ? 'Evaluating...' : 'Run AI Evaluation'}
                                    </button>
                                    <div aria-live="polite" aria-busy={isLoading}>
                                        {error && <div className="error-message" role="alert">{error}</div>}
                                        {evaluation && (
                                            <div className="evaluation-results">
                                                <h4>AI Evaluation Results</h4>
                                                <div className="rationale">
                                                    <strong>Rationale:</strong>
                                                    <p>{evaluation.rationale}</p>
                                                </div>
                                                <div className="scores-grid">
                                                    <ScoreIndicator label="Clarity" score={evaluation.clarity} />
                                                    <ScoreIndicator label="Relevance" score={evaluation.relevance} />
                                                    <ScoreIndicator label="Technical Accuracy" score={evaluation.technicalAccuracy} />
                                                    <ScoreIndicator label="Completeness" score={evaluation.completeness} />
                                                </div>
                                                {/* FIX: The aria-valuemin and aria-valuemax attributes for the 'meter' role expect numbers, not strings. */}
                                                <div className="overall-score-container" role="meter" aria-valuenow={evaluation.overallScore} aria-valuemin={0} aria-valuemax={100} aria-label={`Overall Score: ${evaluation.overallScore} out of 100`}>
                                                    Overall Score:
                                                    <span className="overall-score-value">{evaluation.overallScore}%</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </>
                        ) : (
                            <div className="no-candidate-selected">
                                <p>Select a candidate from the left to view their interview results.</p>
                            </div>
                        )}
                    </main>
                </div>
            </section>
        </div>
    );
};