/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import './ResultsScreen.css';

// Mock data to simulate a completed interview log
const MOCK_INTERVIEW_LOG = [
    {
        question: "Can you walk me through your experience with React and state management libraries like Redux or MobX?",
        answer: "Sure. I've worked extensively with React for about five years now. In my previous role, I was the lead on a project where we used Redux for managing a very complex application state with lots of asynchronous actions. I'm very comfortable with writing actions, reducers, and using middleware like Redux Thunk. I've also dabbled with MobX on personal projects and appreciate its simplicity for smaller-scale apps."
    },
    {
        question: "Describe a challenging project you worked on. What was the problem, what was your role, and what was the outcome?",
        answer: "The most challenging project was a legacy code migration from Angular.js to React. I was responsible for planning the phased rollout to avoid disrupting users. The main problem was untangling years of coupled code. We successfully migrated the entire application over six months with zero downtime, which was a huge win."
    },
    {
        question: "How do you ensure the performance and accessibility of a web application you are building?",
        answer: "For performance, I focus on things like code splitting with React.lazy, memoization with React.memo and useMemo to prevent unnecessary re-renders, and virtualizing long lists. On the accessibility front, I always use semantic HTML, manage focus properly in complex components, and ensure all interactive elements are keyboard-navigable. I also use tools like Axe for automated testing."
    }
];

interface Analysis {
    summary: string;
    strengths: string[];
    areasForImprovement: string[];
}

export const ResultsScreen = () => {
    const [analysis, setAnalysis] = useState<Analysis | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const generateAnalysis = async () => {
            setIsLoading(true);
            setError('');
            try {
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

                const transcript = MOCK_INTERVIEW_LOG.map((item, index) => 
                    `Question ${index + 1}: ${item.question}\nAnswer ${index + 1}: ${item.answer}`
                ).join('\n\n');

                const prompt = `
                    Based on the following interview transcript for a 'Senior Frontend Developer' role, provide a concise performance analysis.
                    The analysis should be constructive and professional, suitable for a hiring manager's review.
                    
                    Transcript:
                    ${transcript}

                    Provide your analysis in a structured JSON format.
                `;
                
                const response = await ai.models.generateContent({
                    model: "gemini-2.5-flash",
                    contents: prompt,
                    config: {
                        systemInstruction: "You are an expert technical recruiter AI. Your task is to analyze an interview transcript and provide a summary, key strengths, and areas for improvement.",
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                summary: { type: Type.STRING, description: "A brief overall summary of the candidate's performance." },
                                strengths: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of the candidate's key strengths." },
                                areasForImprovement: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of potential areas for improvement or further discussion." }
                            },
                            required: ["summary", "strengths", "areasForImprovement"]
                        }
                    }
                });

                const jsonStr = response.text.trim();
                const result = JSON.parse(jsonStr);
                setAnalysis(result);

            } catch (e) {
                console.error(e);
                setError('Failed to generate performance analysis. Please try again later.');
            } finally {
                setIsLoading(false);
            }
        };

        generateAnalysis();
    }, []);

    const handleDownload = () => {
        alert("Certificate download functionality coming soon!");
    }
    
    const candidateName = "Samantha Jones";
    const certificateId = `SI-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const qrText = `Certificate ID: ${certificateId}\nCandidate: ${candidateName}\nVerified by Smart Interview AI`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(qrText)}`;


    return (
        <div className="results-screen-container">
            <div className="certificate-wrapper">
                <div className="certificate">
                    <div className="cert-border-top"></div>
                    <div className="cert-border-right"></div>
                    <div className="cert-border-bottom"></div>
                    <div className="cert-border-left"></div>
                    <div className="cert-content">
                        <div className="cert-header">
                            <div className="logo-small"></div>
                            <h1>Smart Interview AI</h1>
                            <h2>Certificate of Completion</h2>
                        </div>
                        <div className="cert-body">
                            <p className="cert-intro">This is to certify that</p>
                            <h3 className="cert-name">{candidateName}</h3>
                            <p className="cert-details">
                                has successfully completed the AI-powered screening interview for the role of <strong>Senior Frontend Developer</strong> with an overall score of <strong>87%</strong>.
                            </p>
                            <p className="cert-date">Issued on: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        </div>
                        <div className="cert-footer">
                            <div className="cert-verification">
                                <img src={qrCodeUrl} alt="Certificate Verification QR Code" className="qr-code" />
                                <div className="verification-text">
                                    <span>Verifiable Certificate</span>
                                    <span>ID: {certificateId}</span>
                                </div>
                            </div>
                            <div className="cert-seal">
                                <div className="seal-text">Official Seal</div>
                            </div>
                        </div>
                    </div>
                </div>
                <button onClick={handleDownload} className="download-cert-button">Download Certificate</button>
            </div>

            <div className="analysis-wrapper">
                <h2>AI Performance Analysis</h2>
                {isLoading && (
                    <div className="spinner-container">
                        <div className="spinner-big"></div>
                        <p>Analyzing interview...</p>
                    </div>
                )}
                {error && <div className="error-message">{error}</div>}
                {analysis && !isLoading && (
                    <div className="analysis-content">
                        <div className="analysis-section">
                            <h3>Overall Summary</h3>
                            <p>{analysis.summary}</p>
                        </div>
                        <div className="analysis-section">
                            <h3>Key Strengths</h3>
                            <ul>
                                {analysis.strengths.map((strength, i) => (
                                    <li key={i}>{strength}</li>
                                ))}
                            </ul>
                        </div>
                        <div className="analysis-section">
                            <h3>Areas for Improvement</h3>
                             <ul>
                                {analysis.areasForImprovement.map((area, i) => (
                                    <li key={i}>{area}</li>
                                ))}
                            </ul>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
