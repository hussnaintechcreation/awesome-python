import React, { useState, useEffect } from 'react';
import './CandidatePortal.css';
import { InterviewScreen } from './InterviewScreen';
import { ResultsScreen } from './ResultsScreen';

const INTERVIEW_SESSION_KEY = 'smartInterviewSession';

export const CandidatePortal = ({ onLogout }) => {
    const [interviewState, setInterviewState] = useState('welcome'); // 'welcome', 'resume-prompt', 'in-progress', 'awaiting-review', 'completed'
    const [permissionsGranted, setPermissionsGranted] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        const savedSession = localStorage.getItem(INTERVIEW_SESSION_KEY);
        if (savedSession) {
            setInterviewState('resume-prompt');
        }
    }, []);

    const handleStartInterview = async () => {
        setError('');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
            setPermissionsGranted(true);
            setInterviewState('in-progress');
            // We don't need to keep the stream, just need to get permission
            stream.getTracks().forEach(track => track.stop());
        } catch (error) {
            console.error("Microphone and/or camera access denied:", error);
            setError("Microphone and camera access are required. Please allow access in your browser settings and try again.");
            setPermissionsGranted(false);
        }
    };
    
    const handleInterviewComplete = (log) => {
        localStorage.removeItem(INTERVIEW_SESSION_KEY); // Clean up on completion
        console.log("Interview Log:", log); // Here you would normally send this to your backend
        setInterviewState('awaiting-review');
        // Simulate a delay for processing and admin approval before showing results
        setTimeout(() => {
            setInterviewState('completed');
        }, 3000);
    }

    const handleResume = () => {
        // Permissions are implicitly granted if they started before.
        // We'll proceed directly to the interview screen which will load their state.
        setInterviewState('in-progress');
    };

    const handleStartNew = () => {
        localStorage.removeItem(INTERVIEW_SESSION_KEY);
        setInterviewState('welcome'); // Go back to the welcome screen
    };

    const handleLogoutClick = () => {
        if (window.confirm('Are you sure you want to log out?')) {
            localStorage.removeItem(INTERVIEW_SESSION_KEY);
            onLogout();
        }
    }

    const renderContent = () => {
        switch (interviewState) {
            case 'resume-prompt':
                return (
                    <div className="welcome-screen">
                        <div className="logo" aria-hidden="true"></div>
                        <h1>Interview in Progress</h1>
                        <div className="instructions-card resume-prompt">
                           <h2>Welcome Back!</h2>
                           <p>We've detected an incomplete interview session. Would you like to resume where you left off or start a new interview?</p>
                           <div className="resume-actions">
                             <button className="start-interview-button" onClick={handleResume}>Resume Interview</button>
                             <button className="start-interview-button secondary" onClick={handleStartNew}>Start New Interview</button>
                           </div>
                        </div>
                    </div>
                );
            case 'in-progress':
                return <InterviewScreen onComplete={handleInterviewComplete} />;
            case 'awaiting-review':
                 return (
                    <div className="welcome-screen">
                        <div className="logo" aria-hidden="true"></div>
                        <h1>Thank You!</h1>
                        <p className="job-title">Your interview has been submitted successfully.</p>
                        <div className="instructions-card">
                           <div className="spinner-big" role="status" aria-label="Processing results"></div>
                           <h2 style={{marginTop: '1.5rem'}}>Your results are being processed by our AI.</h2>
                           <p>The hiring team will review your submission shortly. You will be redirected to the results page momentarily.</p>
                        </div>
                    </div>
                );
            case 'completed':
                return <ResultsScreen />;
            case 'welcome':
            default:
                return (
                    <div className="welcome-screen">
                        <div className="logo" aria-hidden="true"></div>
                        <h1>Your AI-Powered Interview Awaits</h1>
                        <p className="job-title">Role: Senior Frontend Developer</p>
                        <div className="instructions-card">
                            <h2>Instructions</h2>
                            <ul>
                                <li>Ensure you are in a quiet environment.</li>
                                <li>Grant access to both your camera and microphone when prompted.</li>
                                <li>You will be asked a series of questions one by one.</li>
                                <li>Each question has a time limit for you to answer.</li>
                                <li>Speak clearly into your microphone to answer. Your speech will be transcribed in real-time.</li>
                                <li>Once you are ready, click the button below to begin.</li>
                            </ul>
                        </div>
                        {error && <div className="error-display" role="alert">{error}</div>}
                        <button className="start-interview-button" onClick={handleStartInterview}>
                            Check Permissions & Start Interview
                        </button>
                    </div>
                );
        }
    }

    return (
        <div className="candidate-portal-container">
            <header className="candidate-header">
                <div className="candidate-brand">
                    <div className="logo" aria-hidden="true"></div>
                    <h2>Smart Interview</h2>
                </div>
                <button onClick={handleLogoutClick} className="candidate-logout-button">Logout</button>
            </header>
            <main className="candidate-main">
                {renderContent()}
            </main>
            <div className="powered-by-footer">
              Powered by HUSSNAIN'S TECH CREATION PVT LTD. (OWNER AND APP DEVELOPER)
            </div>
        </div>
    );
};