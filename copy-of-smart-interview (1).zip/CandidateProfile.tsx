import React, { useState, useEffect, useRef } from 'react';
import { initialCandidates } from './CandidateManagement';
import './CandidateProfile.css';

const NOTES_STORAGE_PREFIX = 'smartInterview_profile_';

export const CandidateProfile = ({ candidateId, navigate }) => {
    const [candidate, setCandidate] = useState(null);
    const [notes, setNotes] = useState('');
    const [rating, setRating] = useState(0);
    const notesEditorRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const foundCandidate = initialCandidates.find(c => c.id === candidateId);
        if (foundCandidate) {
            setCandidate(foundCandidate);
            // Load notes and rating from localStorage
            const savedProfile = localStorage.getItem(`${NOTES_STORAGE_PREFIX}${candidateId}`);
            if (savedProfile) {
                const { notes: savedNotes, rating: savedRating } = JSON.parse(savedProfile);
                setNotes(savedNotes || '');
                setRating(savedRating || 0);
            } else {
                // Reset for new candidate
                setNotes('');
                setRating(0);
            }
        } else {
            setCandidate(null);
        }
    }, [candidateId]);
    
    // Effect to sync the state to the editor's DOM after state is updated from localStorage.
    useEffect(() => {
        if (notesEditorRef.current && notesEditorRef.current.innerHTML !== notes) {
            notesEditorRef.current.innerHTML = notes;
        }
    }, [notes, candidateId]);


    const handleSave = () => {
        const profileData = JSON.stringify({ notes, rating });
        localStorage.setItem(`${NOTES_STORAGE_PREFIX}${candidateId}`, profileData);
        alert('Notes and rating saved!'); // Simple confirmation
    };
    
    const getStatusClass = (status) => {
        return `status-${status.toLowerCase().replace(/ /g, '')}`;
    };

    const applyFormat = (command: string) => {
        document.execCommand(command, false, undefined);
        if (notesEditorRef.current) {
            setNotes(notesEditorRef.current.innerHTML);
        }
        notesEditorRef.current?.focus();
    };

    const handleRatingKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
        e.preventDefault();
        let newRating = rating;
        if (e.key === 'ArrowRight') {
            newRating = Math.min(5, rating + 1);
        } else if (e.key === 'ArrowLeft') {
            newRating = Math.max(1, rating - 1);
        } else if (e.key === 'ArrowDown') {
             newRating = 1;
        } else if (e.key === 'ArrowUp') {
            newRating = 5;
        }
        
        if (newRating !== rating) {
            setRating(newRating);
            // Focus the newly selected radio button
            const nextStar = e.currentTarget.querySelector(`[aria-label^="${newRating} star"]`) as HTMLButtonElement;
            nextStar?.focus();
        }
    };

    if (!candidate) {
        return (
            <div className="candidate-profile-panel">
                <header className="page-header">
                    <h2>Candidate Not Found</h2>
                    <p>The selected candidate could not be found. They may have been removed.</p>
                    <button className="back-link" onClick={() => navigate('#/candidates')}>
                        ← Back to All Candidates
                    </button>
                </header>
            </div>
        );
    }

    return (
        <div className="candidate-profile-panel">
            <header className="profile-page-header">
                <div>
                    <h2>{candidate.name}</h2>
                    <p>{candidate.email}</p>
                </div>
                <div className={`status-badge-large ${getStatusClass(candidate.status)}`}>
                    {candidate.status}
                </div>
            </header>

            <div className="profile-layout">
                <div className="profile-main-content">
                    <section className="profile-section" aria-labelledby="notes-heading">
                        <h3 id="notes-heading">Private Notes</h3>
                        <div className="notes-editor-container" tabIndex={-1}>
                            <div className="notes-toolbar" role="toolbar">
                                <button type="button" onClick={() => applyFormat('bold')} aria-label="Bold"><b>B</b></button>
                                <button type="button" onClick={() => applyFormat('italic')} aria-label="Italic"><i>I</i></button>
                                <button type="button" onClick={() => applyFormat('underline')} aria-label="Underline"><u>U</u></button>
                            </div>
                            <div
                                ref={notesEditorRef}
                                className="notes-editor"
                                contentEditable="true"
                                onInput={(e) => setNotes(e.currentTarget.innerHTML)}
                                aria-labelledby="notes-heading"
                                role="textbox"
                            ></div>
                        </div>
                    </section>
                    <section className="profile-section" aria-labelledby="history-heading">
                        <h3 id="history-heading">Interview History</h3>
                        <div className="interview-history-list">
                            {candidate.interviewHistory.length > 0 ? (
                                candidate.interviewHistory.map(interview => (
                                    <div key={interview.id} className="history-item">
                                        <div className="history-item-details">
                                            <h4>{interview.role}</h4>
                                            <span>Interview Date: {interview.date}</span>
                                        </div>
                                        <div className="history-item-score">
                                            {interview.score !== null ? (
                                                <>
                                                    <span>Overall Score</span>
                                                    <p>{interview.score}%</p>
                                                </>
                                            ) : (
                                                <span className="pending-score">Awaiting Review</span>
                                            )}
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <p className="no-history">No interview history for this candidate.</p>
                            )}
                        </div>
                    </section>
                </div>
                <aside className="profile-sidebar">
                    <section className="profile-section">
                        <h3 id="rating-heading">Overall Rating</h3>
                        <div 
                            className="star-rating" 
                            role="radiogroup"
                            aria-labelledby="rating-heading"
                            onKeyDown={handleRatingKeyDown}
                        >
                            {[1, 2, 3, 4, 5].map((star, index) => (
                                <button
                                    key={star}
                                    role="radio"
                                    aria-checked={star === rating}
                                    aria-label={`${star} star${star > 1 ? 's' : ''}`}
                                    className={`star-button ${star <= rating ? 'filled' : ''}`}
                                    onClick={() => setRating(star)}
                                    // Manage focus for keyboard navigation
                                    tabIndex={rating === 0 ? (index === 0 ? 0 : -1) : (star === rating ? 0 : -1)}
                                >
                                    ★
                                </button>
                            ))}
                        </div>
                    </section>
                    <button className="save-button" onClick={handleSave}>
                        Save Notes & Rating
                    </button>
                </aside>
            </div>
        </div>
    );
};
