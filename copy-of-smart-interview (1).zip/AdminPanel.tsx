

import React from 'react';
import './AdminPanel.css';

const mockActivity = [
  { id: 1, type: 'review', description: 'Samantha Jones completed an interview for the Senior Frontend Developer role.', time: '1h ago' },
  { id: 2, type: 'approved', description: 'Alex Doe was approved.', time: '3h ago' },
  { id: 3, type: 'invite', description: 'Michael Chen was invited to interview.', time: '1d ago' },
  { id: 4, type: 'template', description: 'A new template "UX/UI Designer" was created.', time: '2d ago' },
  { id: 5, type: 'invite', description: 'Jessica Davis was invited to interview.', time: '2d ago' },
];

export const AdminPanel = () => {
  return (
    <div className="admin-panel-container">
        <div className="admin-panel-content">
          <header className="page-header">
            <h2>Welcome, Admin!</h2>
            <p>Here's a quick overview of your platform's activity.</p>
          </header>
          <main className="dashboard-grid">
            <div className="summary-card">
              <h3>Total Candidates</h3>
              <p className="summary-value">4</p>
              <span className="summary-footer">Tracked in pipeline</span>
            </div>
            <div className="summary-card">
              <h3>Interview Templates</h3>
              <p className="summary-value">12</p>
              <span className="summary-footer">Custom templates created</span>
            </div>
            <div className="summary-card">
              <h3>Awaiting Review</h3>
              <p className="summary-value">1</p>
              <span className="summary-footer">Completed interviews to evaluate</span>
            </div>
             <div className="summary-card">
              <h3>Approved Results</h3>
              <p className="summary-value">1</p>
              <span className="summary-footer">Candidates approved</span>
            </div>
          </main>
        </div>
        <aside className="recent-activity-sidebar">
          <h3>Recent Activity</h3>
          <div className="activity-feed">
            {mockActivity.map(item => (
              <div className="activity-item" key={item.id}>
                <div className={`activity-icon ${item.type}`}></div>
                <div className="activity-details">
                  <p>{item.description}</p>
                  <span>{item.time}</span>
                </div>
              </div>
            ))}
          </div>
        </aside>
    </div>
  );
};