/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, useCallback } from 'react';
import './InterviewScreen.css';

const MOCK_QUESTIONS = [
    "Can you walk me through your experience with React and state management libraries like Redux or MobX?",
    "Describe a challenging project you worked on. What was the problem, what was your role, and what was the outcome?",
    "How do you ensure the performance and accessibility of a web application you are building?",
    "Tell me about a time you had a disagreement with a team member. How did you handle it?",
    "Where do you see yourself in five years, and how does this role fit into your career goals?"
];
const TIME_PER_QUESTION = 90; // seconds
const INTERVIEW_SESSION_KEY = 'smartInterviewSession';

// Cast window to `any` to access non-standard SpeechRecognition APIs and add a check for browser support.
// This setup is moved outside the component to prevent re-initialization on every render.
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const recognition = SpeechRecognition ? new SpeechRecognition() : null;
if (recognition) {
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';
}

// Sound effect player utility, moved outside the component as it doesn't depend on component state.
const playSoundEffect = (
    audioContext: AudioContext | null, 
    type: 'start' | 'stop' | 'next'
) => {
    if (!audioContext) return;

    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Set volume envelope to prevent clicks
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + 0.02); // Softer peak volume

    oscillator.type = 'sine';
    let duration = 0.2;

    switch (type) {
        case 'start':
            oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
            oscillator.frequency.linearRampToValueAtTime(783.99, audioContext.currentTime + 0.1); // G5
            break;
        case 'stop':
            oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime); // G5
            oscillator.frequency.linearRampToValueAtTime(523.25, audioContext.currentTime + 0.1); // C5
            break;
        case 'next':
            oscillator.type = 'triangle';
            oscillator.frequency.setValueAtTime(1046.50, audioContext.currentTime); // C6
            duration = 0.15; // Shorter sound for 'next'
            break;
    }

    oscillator.start(audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.00001, audioContext.currentTime + duration);
    oscillator.stop(audioContext.currentTime + duration);
};


export const InterviewScreen = ({ onComplete }) => {
    // Load initial state from localStorage if it exists
    const getInitialState = () => {
        const savedStateJSON = localStorage.getItem(INTERVIEW_SESSION_KEY);
        if (savedStateJSON) {
            try {
                return JSON.parse(savedStateJSON);
            } catch (e) {
                console.error("Failed to parse saved session", e);
                return null;
            }
        }
        return null;
    };
    const savedState = getInitialState();

    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(savedState?.currentQuestionIndex || 0);
    const [transcript, setTranscript] = useState(savedState?.transcript || '');
    const [isRecording, setIsRecording] = useState(false);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [timer, setTimer] = useState(savedState?.timer !== undefined ? savedState.timer : TIME_PER_QUESTION);
    const [visibilityWarnings, setVisibilityWarnings] = useState(0);
    const [interviewLog, setInterviewLog] = useState<{ question: string; answer: string; confidence: number; videoUrl?: string; }[]>(savedState?.interviewLog || []);
    const [videoUrl, setVideoUrl] = useState<string | null>(savedState?.videoUrl || null);
    const [error, setError] = useState('');
    const [interviewStage, setInterviewStage] = useState<'answering' | 'review'>('answering');
    
    const timerId = useRef<number | null>(null);
    const finalTranscript = useRef(savedState?.finalTranscript || '');
    const confidenceScores = useRef<number[]>([]);
    const audioContextRef = useRef<AudioContext | null>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const recordedChunksRef = useRef<Blob[]>([]);
    
    // For microphone visualizer
    const visualizerRef = useRef<HTMLCanvasElement>(null);
    const animationFrameIdRef = useRef<number | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const dataArrayRef = useRef<Uint8Array | null>(null);

    // Save state to localStorage on change
    useEffect(() => {
        if (interviewStage === 'answering' && interviewLog.length < MOCK_QUESTIONS.length) {
            const stateToSave = {
                currentQuestionIndex,
                transcript,
                timer,
                interviewLog,
                finalTranscript: finalTranscript.current,
                videoUrl
            };
            localStorage.setItem(INTERVIEW_SESSION_KEY, JSON.stringify(stateToSave));
        }
    }, [currentQuestionIndex, transcript, timer, interviewLog, videoUrl, interviewStage]);


    const speakQuestion = (text: string) => {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = 0.9;
            utterance.onstart = () => setIsSpeaking(true);
            utterance.onend = () => setIsSpeaking(false);
            utterance.onerror = (event) => {
                console.error("SpeechSynthesis Error", event);
                setIsSpeaking(false);
            };
            window.speechSynthesis.speak(utterance);
        } else {
            console.warn("Speech Synthesis is not supported by this browser.");
        }
    };

    const drawVisualizer = useCallback(() => {
        if (!analyserRef.current || !dataArrayRef.current || !visualizerRef.current) {
            animationFrameIdRef.current = requestAnimationFrame(drawVisualizer);
            return;
        }

        const analyser = analyserRef.current;
        const dataArray = dataArrayRef.current;
        const canvas = visualizerRef.current;
        const canvasCtx = canvas.getContext('2d');
        
        analyser.getByteFrequencyData(dataArray);

        if (canvasCtx) {
            const WIDTH = canvas.width;
            const HEIGHT = canvas.height;
            canvasCtx.clearRect(0, 0, WIDTH, HEIGHT);

            let sum = 0;
            for(const amplitude of dataArray) {
                sum += amplitude;
            }
            const average = sum / dataArray.length;
            const volume = average / 128.0; 
            const barHeight = volume * HEIGHT * 1.5;

            const gradient = canvasCtx.createLinearGradient(0, HEIGHT, 0, HEIGHT - barHeight);
            gradient.addColorStop(0, '#66bb6a'); // Green
            gradient.addColorStop(0.7, '#ffc107'); // Yellow
            gradient.addColorStop(1, '#e57373'); // Red

            canvasCtx.fillStyle = gradient;
            canvasCtx.fillRect(0, HEIGHT - barHeight, WIDTH, barHeight);
        }
        animationFrameIdRef.current = requestAnimationFrame(drawVisualizer);
    }, []);

    useEffect(() => {
        async function setupMedia() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                }
                streamRef.current = stream;

                // Mic visualizer setup
                if (!audioContextRef.current) {
                    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
                }
                const source = audioContextRef.current.createMediaStreamSource(stream);
                const analyser = audioContextRef.current.createAnalyser();
                analyser.fftSize = 256;
                analyser.smoothingTimeConstant = 0.3;
                source.connect(analyser);
                analyserRef.current = analyser;
                dataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);
                
                // Start drawing loop
                animationFrameIdRef.current = requestAnimationFrame(drawVisualizer);

            } catch (error) {
                console.error("Error accessing camera/mic:", error);
                setError("Could not access your camera or microphone. Please check permissions and refresh the page.");
            }
        }
        setupMedia();

        return () => {
            // Stop camera and mic on component unmount
            if (streamRef.current) {
                streamRef.current.getTracks().forEach(track => track.stop());
            }
            // Stop animation frame
            if (animationFrameIdRef.current) {
                cancelAnimationFrame(animationFrameIdRef.current);
            }
            // Close audio context
            if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
                audioContextRef.current.close();
            }
        };
    }, [drawVisualizer]);

    useEffect(() => {
        // Only speak the question if it's not a resumed session on the same question
        if (!savedState || savedState.currentQuestionIndex !== currentQuestionIndex) {
            speakQuestion(MOCK_QUESTIONS[currentQuestionIndex]);
        }
        return () => {
            if ('speechSynthesis' in window) {
                window.speechSynthesis.cancel();
            }
        };
    }, [currentQuestionIndex]);
    
    const onRecognitionResult = useCallback((event: any) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                finalTranscript.current += event.results[i][0].transcript + ' ';
                confidenceScores.current.push(event.results[i][0].confidence);
            } else {
                interimTranscript += event.results[i][0].transcript;
            }
        }
        setTranscript(finalTranscript.current + interimTranscript);
    }, []);

    useEffect(() => {
        if (!recognition) return;
        recognition.onresult = onRecognitionResult;
        recognition.onerror = (event) => {
            console.error("Speech recognition error", event.error);
        };
        return () => {
            if (recognition) {
              recognition.onresult = null;
              recognition.onerror = null;
            }
        }
    }, [onRecognitionResult]);

    useEffect(() => {
        const handleVisibilityChange = () => {
            if (document.hidden) {
                setVisibilityWarnings(prev => prev + 1);
            }
        };
        document.addEventListener('visibilitychange', handleVisibilityChange);
        return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
    }, []);

    const stopAndFinalizeRecording = useCallback(() => {
        return new Promise<string | null>((resolve) => {
            if (!isRecording) {
                resolve(videoUrl); // Already stopped, return existing URL
                return;
            }
            if (recognition) recognition.stop();
            if (mediaRecorderRef.current) {
                mediaRecorderRef.current.onstop = () => {
                    const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
                    const url = URL.createObjectURL(blob);
                    setVideoUrl(url); // Update state for UI changes
                    resolve(url);
                };
                if (mediaRecorderRef.current.state === "recording") {
                    mediaRecorderRef.current.stop();
                } else {
                    resolve(videoUrl);
                }
            } else {
                resolve(null);
            }
            playSoundEffect(audioContextRef.current, 'stop');
            setIsRecording(false);
        });
    }, [isRecording, videoUrl]);


    const handleStopRecording = useCallback(() => {
        if(isRecording) stopAndFinalizeRecording();
    }, [isRecording, stopAndFinalizeRecording]);


     useEffect(() => {
        if (isRecording) {
            timerId.current = window.setInterval(() => {
                setTimer(prev => {
                    if (prev <= 1) {
                        handleStopRecording();
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        } else {
            if(timerId.current) clearInterval(timerId.current);
        }
        return () => {
            if(timerId.current) clearInterval(timerId.current);
        };
    }, [isRecording, handleStopRecording]);

    const handleStartRecording = () => {
        if (!isRecording && recognition && streamRef.current) {
            playSoundEffect(audioContextRef.current, 'start');
            finalTranscript.current = '';
            setTranscript('');
            confidenceScores.current = [];
            recognition.start();

            // Video recording
            recordedChunksRef.current = [];
            setVideoUrl(null); // Clear previous video
            mediaRecorderRef.current = new MediaRecorder(streamRef.current, { mimeType: 'video/webm' });

            mediaRecorderRef.current.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    recordedChunksRef.current.push(event.data);
                }
            };
            
            mediaRecorderRef.current.onstop = () => {
                const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
                const url = URL.createObjectURL(blob);
                setVideoUrl(url);
            };

            mediaRecorderRef.current.start();
            setIsRecording(true);
            setTimer(TIME_PER_QUESTION);
        }
    };

    const handleNextQuestion = async () => {
        const recordedVideoUrl = await stopAndFinalizeRecording();
        playSoundEffect(audioContextRef.current, 'next');

        const calculateAverageConfidence = () => {
            if (confidenceScores.current.length === 0) {
                return 0;
            }
            const sum = confidenceScores.current.reduce((a, b) => a + b, 0);
            return (sum / confidenceScores.current.length) * 100; // Return as a percentage
        };

        const avgConfidence = calculateAverageConfidence();
        const currentAnswer = finalTranscript.current.trim() || (transcript.trim() ? transcript.trim() : 'No answer recorded.');
        const updatedLog = [...interviewLog, { 
            question: MOCK_QUESTIONS[currentQuestionIndex], 
            answer: currentAnswer,
            confidence: avgConfidence,
            videoUrl: recordedVideoUrl || undefined
        }];
        setInterviewLog(updatedLog);

        if (currentQuestionIndex < MOCK_QUESTIONS.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
            setTimer(TIME_PER_QUESTION);
            setTranscript('');
            finalTranscript.current = '';
            setVideoUrl(null);
            confidenceScores.current = [];
        } else {
            // This is the final question, clean up and go to review stage
            localStorage.removeItem(INTERVIEW_SESSION_KEY);
            setInterviewStage('review');
        }
    };

    if (!recognition) {
        return (
            <div className="interview-screen-container">
                <div className="error-display centered-error">
                    <h3>Feature Not Supported</h3>
                    <p>Sorry, the Speech Recognition API is not supported by your browser.<br />Please use a modern browser like Google Chrome.</p>
                </div>
            </div>
        );
    }
    
    const isLastQuestion = currentQuestionIndex === MOCK_QUESTIONS.length - 1;

    const renderAnsweringScreen = () => (
         <>
            <div className="interview-top-bar">
                <div className="question-progress">
                    Question {currentQuestionIndex + 1} of {MOCK_QUESTIONS.length}
                </div>
                {visibilityWarnings > 0 && (
                    <div className="visibility-warning" role="alert">
                        Focus warning: Navigated away from tab {visibilityWarnings} time(s).
                    </div>
                )}
            </div>
            
            <div className="media-container">
                <div className="question-display-card">
                    {isSpeaking && <div className="speaker-icon" aria-label="AI is speaking"></div>}
                    <p>{MOCK_QUESTIONS[currentQuestionIndex]}</p>
                </div>

                <div className="video-preview-container">
                    <video ref={videoRef} autoPlay muted playsInline className="video-preview"></video>
                    {isRecording && <div className="recording-indicator">REC</div>}
                    <div className="mic-visualizer-container">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18" aria-hidden="true"><path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.42 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"></path></svg>
                        <canvas ref={visualizerRef} width="80" height="24"></canvas>
                    </div>
                </div>
            </div>

            <div className="interview-controls">
                <div className={`timer ${timer <= 10 ? 'low-time' : ''}`}>
                    {Math.floor(timer / 60)}:{('0' + timer % 60).slice(-2)}
                </div>
                <button 
                    className={`record-button ${isRecording ? 'recording' : ''}`}
                    onClick={isRecording ? handleStopRecording : handleStartRecording}
                    aria-label={isRecording ? 'Stop Recording' : 'Start Recording'}
                    disabled={(timer === 0 && !isRecording) || isSpeaking}
                >
                    <span className="record-icon"></span>
                    {isRecording ? 'Stop Answering' : (isSpeaking ? 'Please Wait...' : 'Start Answering')}
                </button>
            </div>
            
            <div className="transcript-container">
                <h3>Your Answer (Live Transcription):</h3>
                <div className="transcript-box" aria-live="polite">
                    {transcript || <span className="placeholder-text">Your transcribed answer will appear here...</span>}
                </div>
            </div>

            <button 
                className="next-question-button" 
                onClick={handleNextQuestion}
                disabled={isRecording && timer > 0}
            >
                {isLastQuestion ? 'Finish Interview' : 'Next Question'}
            </button>
        </>
    );
    
    const renderReviewScreen = () => (
        <div className="interview-review-container">
            <header className="page-header">
                <h2>Interview Complete</h2>
                <p>Please review your responses. You can download a copy of your video for each question. When you are ready, submit your interview for evaluation.</p>
            </header>
            <div className="review-list">
                {interviewLog.map((logItem, index) => (
                    <div key={index} className="review-item-card">
                        <div className="review-item-content">
                            <h4>Question {index + 1}</h4>
                            <p className="review-question-text">{logItem.question}</p>
                        </div>
                        {logItem.videoUrl ? (
                            <a 
                                href={logItem.videoUrl} 
                                download={`interview_response_q${index + 1}.webm`} 
                                className="download-video-button"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18" aria-hidden="true"><path d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z"></path></svg>
                                Download
                            </a>
                        ) : (
                            <span className="no-video-notice">No video recorded</span>
                        )}
                    </div>
                ))}
            </div>
            <button
                className="submit-interview-button"
                onClick={() => onComplete(interviewLog)}
            >
                Submit Interview for Analysis
            </button>
        </div>
    );

    return (
        <div className="interview-screen-container">
            {error && <div className="error-display">{error}</div>}
            {interviewStage === 'answering' ? renderAnsweringScreen() : renderReviewScreen()}
        </div>
    );
};
