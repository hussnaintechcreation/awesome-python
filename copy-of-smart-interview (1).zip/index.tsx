/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { AuthPage } from './AuthPage';
import { AdminPanel } from './AdminPanel';
import { CandidateManagement } from './CandidateManagement';
import { CustomInterviewBuilder } from './CustomInterviewBuilder';
import { ThemeSettings } from './ThemeSettings';
import { CandidatePortal } from './CandidatePortal';
import { ResultsAnalytics } from './ResultsAnalytics';
import { CandidateProfile } from './CandidateProfile';

// A new sophisticated and corporate default theme
const defaultTheme: {[key: string]: string} = {
  '--primary-bg': '#0D1117',
  '--secondary-bg': '#161B22',
  '--card-bg': '#1E242C',
  '--primary-accent': '#B39DDB', // Lighter for contrast
  '--secondary-accent': '#8B949E',
  '--text-primary': '#F0F6FC',
  '--text-secondary': '#C9D1D9',
  '--border-color': '#30363D',
};

const App = () => {
  const [userRole, setUserRole] = useState<string | null>(null);
  const [hash, setHash] = useState(window.location.hash);
  const [theme, setThemeState] = useState(defaultTheme);
  
  // Helper for navigation
  const navigate = (path: string) => {
    window.location.hash = path;
  };

  useEffect(() => {
    const handleHashChange = () => {
      setHash(window.location.hash);
    };
    window.addEventListener('hashchange', handleHashChange);
    // Set initial hash
    if (!window.location.hash) {
      window.location.hash = '#/login';
    }
    handleHashChange(); // Sync state on initial load
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);
  
  // Redirect unauthenticated users
  useEffect(() => {
    if (!userRole && hash !== '#/login') {
      navigate('#/login');
    }
  }, [userRole, hash]);


  const applyTheme = (themeObject: {[key: string]: string}) => {
    for (const key in themeObject) {
      document.documentElement.style.setProperty(key, themeObject[key]);
    }
    setThemeState(themeObject);
  };
  
  useEffect(() => {
    applyTheme(theme);
  }, []);

  const handleLogin = (role: string) => {
    setUserRole(role);
    if (role === 'admin') {
      navigate('#/dashboard');
    } else {
      navigate('#/portal');
    }
  };

  const handleLogout = () => {
    setUserRole(null);
    navigate('#/login');
  };

  const renderAdminContent = () => {
    if (hash.startsWith('#/candidates/')) {
        const candidateId = hash.split('/')[2];
        if (candidateId && !isNaN(parseInt(candidateId, 10))) {
            return <CandidateProfile candidateId={parseInt(candidateId, 10)} navigate={navigate} />;
        }
    }
    
    switch (hash) {
      case '#/dashboard':
        return <AdminPanel />;
      case '#/candidates':
        return <CandidateManagement navigate={navigate} />;
      case '#/builder':
        return <CustomInterviewBuilder />;
       case '#/results':
        return <ResultsAnalytics />;
      case '#/settings':
        return <ThemeSettings setTheme={applyTheme} defaultTheme={defaultTheme} />;
      default:
        // If an admin is logged in but the hash is invalid, redirect to dashboard
        if(userRole === 'admin') navigate('#/dashboard');
        return <AdminPanel />;
    }
  };

  if (!userRole) {
    return <AuthPage onLogin={handleLogin} />;
  }

  if (userRole === 'candidate') {
    return <CandidatePortal onLogout={handleLogout} />;
  }
  
  const showBackButton = hash.startsWith('#/candidates/');
  const backButtonNavTarget = '#/candidates';
  const htcLogoUrl = "data:image/svg+xml,%3csvg width='30' height='30' viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3e%3cdefs%3e%3clinearGradient id='htcLogoGrad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3e%3cstop offset='0%25' style='stop-color:%23A78BFA;stop-opacity:1' /%3e%3cstop offset='100%25' style='stop-color:%238B5CF6;stop-opacity:1' /%3e%3c/linearGradient%3e%3c/defs%3e%3cpath d='M15 1 L28 8 V22 L15 29 L2 22 V8 Z' fill='none' stroke='url(%23htcLogoGrad)' stroke-width='1.5' /%3e%3ctext x='50%25' y='55%25' dominant-baseline='middle' text-anchor='middle' font-family='Poppins, sans-serif' font-weight='700' font-size='9' fill='%23F0F6FC'%3eHTC%3c/text%3e%3c/svg%3e";

  const navLinks = [
    { path: '#/dashboard', label: 'Dashboard' },
    { path: '#/builder', label: 'Interview Builder' },
    { path: '#/candidates', label: 'Candidates' },
    { path: '#/results', label: 'Results & Analytics' },
    { path: '#/settings', label: 'Theme Settings' },
  ];

  return (
    <div className="dashboard-layout">
      <aside className="sidebar">
        <div className="sidebar-header">
          {showBackButton && (
              <button onClick={() => navigate(backButtonNavTarget)} className="sidebar-back-button" aria-label="Go back">
                  ‹
              </button>
          )}
          <div className="logo" aria-hidden="true"></div>
          <div className="sidebar-title-wrapper">
            <h1>Smart Interview</h1>
            <span className="admin-label">ADMIN PANEL</span>
          </div>
        </div>
        <nav className="sidebar-nav" aria-label="Main Navigation">
          {navLinks.map(link => {
            const isActive = link.path === '#/candidates' ? hash.startsWith('#/candidates') : hash === link.path;
            return (
              <a 
                key={link.path}
                href={link.path}
                className={`nav-item ${isActive ? 'active' : ''}`}
                onClick={(e) => { e.preventDefault(); navigate(link.path); }}
                aria-current={isActive ? 'page' : undefined}
              >
                {link.label}
              </a>
            );
          })}
        </nav>
        <div className="sidebar-footer">
          <button className="logout-button" onClick={() => {
            if (window.confirm('Are you sure you want to log out?')) {
              handleLogout();
            }
          }}>Logout</button>
        </div>
      </aside>
      <main className="main-content" role="main">
        <div className="content-wrapper">
            {renderAdminContent()}
        </div>
        <footer className="powered-by-footer">
            Powered by 
            <img src={htcLogoUrl} alt="Hussnain's Tech Creation Logo" className="footer-logo" />
            HUSSNAIN'S TECH CREATION PVT LTD. (OWNER AND APP DEVELOPER)
        </footer>
      </main>
    </div>
  );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);