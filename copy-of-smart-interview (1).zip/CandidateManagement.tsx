import React, { useState, useRef, useMemo } from 'react';
import './CandidateManagement.css';

export const initialCandidates = [
  { 
    id: 1, 
    name: 'Alex Doe',
    email: 'alex.doe@example.com', 
    status: 'Approved',
    interviewHistory: [
        { id: 'int-101', role: 'Senior Frontend Developer', date: '2024-05-10', score: 87 },
        { id: 'int-100', role: 'Mid-Level React Engineer', date: '2024-03-02', score: 92 },
    ]
  },
  { 
    id: 2, 
    name: 'Samantha Jones',
    email: 'samantha.jones@example.com', 
    status: 'Awaiting Review',
    interviewHistory: [
      { id: 'int-102', role: 'Senior Frontend Developer', date: '2024-05-12', score: null },
    ]
  },
  { 
    id: 3, 
    name: 'Michael Chen',
    email: 'michael.chen@example.com', 
    status: 'Pending',
    interviewHistory: []
  },
  { 
    id: 4, 
    name: 'Jessica Davis',
    email: 'jessica.davis@example.com', 
    status: 'Pending',
    interviewHistory: []
  },
];

const filterOptions = ['All', 'Pending', 'Awaiting Review', 'Approved'];

const getProgressProps = (status) => {
    switch (status) {
        case 'Pending':
            return { percentage: 10, colorClass: 'progress-pending' };
        case 'Awaiting Review':
            return { percentage: 60, colorClass: 'progress-review' };
        case 'Approved':
            return { percentage: 100, colorClass: 'progress-approved' };
        default:
            return { percentage: 0, colorClass: '' };
    }
};


export const CandidateManagement = ({ navigate }) => {
  const [candidates, setCandidates] = useState(initialCandidates);
  const [newCandidateEmail, setNewCandidateEmail] = useState('');
  const [isInviting, setIsInviting] = useState(false);
  const [bulkEmails, setBulkEmails] = useState('');
  const [isBulkInviting, setIsBulkInviting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<{ field: string, message: string } | null>(null);
  const [activeFilter, setActiveFilter] = useState('All');
  const [sortConfig, setSortConfig] = useState<{ key: 'email' | 'status' | 'score', direction: 'ascending' | 'descending' }>({ key: 'email', direction: 'ascending' });
  const [searchQuery, setSearchQuery] = useState('');


  const handleInvite = async (e) => {
    e.preventDefault();
    setError(null);
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newCandidateEmail)) {
        setError({ field: 'invite', message: 'Please enter a valid email address.' });
        return;
    };

    setIsInviting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newCandidate = {
      id: candidates.length > 0 ? Math.max(...candidates.map(c => c.id)) + 1 : 1,
      name: 'New Candidate',
      email: newCandidateEmail,
      status: 'Pending',
      interviewHistory: [],
    };
    setCandidates([newCandidate, ...candidates]);
    setNewCandidateEmail('');
    setIsInviting(false);
  };

  const handleBulkInvite = async (e) => {
    e.preventDefault();
    setIsBulkInviting(true);
    setError(null);
  
    const processEmails = (emailList: string[]) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      let validEmails = new Set<string>();
      let invalidCount = 0;
  
      emailList.forEach(email => {
        const trimmedEmail = email.trim();
        if (trimmedEmail) {
          if (emailRegex.test(trimmedEmail)) {
            validEmails.add(trimmedEmail);
          } else {
            invalidCount++;
          }
        }
      });
      return { validEmails: Array.from(validEmails), invalidCount };
    };
  
    let emailsToProcess: string[] = [];
    const file = fileInputRef.current?.files?.[0];
  
    if (file) {
      try {
        const text = await file.text();
        emailsToProcess = text.split(/[\n,]/).filter(line => line.trim() !== '');
      } catch (error) {
        setError({ field: 'bulk', message: 'Error reading the CSV file.' });
        setIsBulkInviting(false);
        return;
      }
    } else {
      emailsToProcess = bulkEmails.split(/[,\s\n]+/).filter(email => email.trim() !== '');
    }
  
    const { validEmails, invalidCount } = processEmails(emailsToProcess);
  
    if (validEmails.length === 0) {
      setError({ field: 'bulk', message: 'No valid email addresses found to invite.' });
      setIsBulkInviting(false);
      return;
    }
  
    // Simulate network request
    await new Promise(resolve => setTimeout(resolve, 1500));
  
    let currentMaxId = candidates.length > 0 ? Math.max(...candidates.map(c => c.id)) : 0;
    const newCandidates = validEmails.map(email => {
      currentMaxId++;
      return {
        id: currentMaxId,
        name: 'New Candidate',
        email: email,
        status: 'Pending',
        interviewHistory: [],
      };
    });
  
    setCandidates(prev => [...newCandidates, ...prev]);
  
    // Reset form state
    setBulkEmails('');
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
    setIsBulkInviting(false);
  
    let summaryMessage = `Successfully invited ${newCandidates.length} candidate(s).`;
    if (invalidCount > 0) {
      summaryMessage += `\n${invalidCount} invalid or empty entries were skipped.`;
    }
    alert(summaryMessage);
  };

  const handleDeleteCandidate = (candidateId: number) => {
    if (window.confirm('Are you sure you want to delete this candidate? This action cannot be undone.')) {
        setCandidates(prev => prev.filter(c => c.id !== candidateId));
    }
  };

  const getStatusClass = (status) => {
    return `status-${status.toLowerCase().replace(/ /g, '')}`;
  };
  
  const requestSort = (key: 'email' | 'status' | 'score') => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
        direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const getSortIndicator = (key: 'email' | 'status' | 'score') => {
    if (sortConfig.key !== key) {
        return null;
    }
    return <span className="sort-indicator" aria-hidden="true">{sortConfig.direction === 'ascending' ? '▲' : '▼'}</span>;
  };

  const displayCandidates = useMemo(() => {
    let filteredItems = [...candidates];

    // 1. Filter by status
    if (activeFilter !== 'All') {
        filteredItems = filteredItems.filter(candidate => candidate.status === activeFilter);
    }
    
    // 2. Filter by search query
    if (searchQuery) {
        filteredItems = filteredItems.filter(candidate => 
            candidate.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
            candidate.name.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }

    // 3. Sort
    filteredItems.sort((a, b) => {
        const key = sortConfig.key;
        let valA, valB;

        if (key === 'score') {
            // Get latest score, treat null/undefined as a very low number for sorting
            valA = a.interviewHistory[0]?.score ?? -1;
            valB = b.interviewHistory[0]?.score ?? -1;
        } else {
            valA = a[key];
            valB = b[key];
        }
        
        if (valA < valB) {
            return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (valA > valB) {
            return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
    });

    return filteredItems;
  }, [candidates, activeFilter, sortConfig, searchQuery]);
  
  const handleExportCSV = () => {
    if (displayCandidates.length === 0) {
        alert("No candidates to export based on current filters.");
        return;
    }

    // Define headers
    const headers = ['ID', 'Name', 'Email', 'Status', 'Latest Score'];
    const csvRows = [headers.join(',')];

    // Create rows
    for (const candidate of displayCandidates) {
        const latestScore = candidate.interviewHistory[0]?.score ?? 'N/A';
        const row = [
            candidate.id,
            `"${candidate.name.replace(/"/g, '""')}"`, // Escape double quotes
            `"${candidate.email.replace(/"/g, '""')}"`,
            `"${candidate.status.replace(/"/g, '""')}"`,
            latestScore
        ].join(',');
        csvRows.push(row);
    }

    // Create blob and trigger download
    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `candidates_export_${new Date().toISOString().slice(0,10)}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };


  return (
    <div className="candidate-management-panel">
      <header className="page-header">
        <h2>Candidate Management</h2>
      </header>
      
      <section className="cm-section" aria-labelledby="invite-heading">
        <h3 id="invite-heading">Invite a Candidate</h3>
        <form onSubmit={handleInvite} className="invite-form">
          <label htmlFor="invite-email" className="sr-only">Candidate Email</label>
          <input 
            type="email" 
            id="invite-email"
            placeholder="Enter candidate's email address" 
            value={newCandidateEmail}
            onChange={(e) => { setNewCandidateEmail(e.target.value); setError(null); }}
            required
            disabled={isInviting}
          />
          <button type="submit" disabled={isInviting}>
            {isInviting ? <span className="spinner" aria-label="Sending invite"></span> : 'Send Invite'}
          </button>
        </form>
        {error && error.field === 'invite' && <div className="error-display" role="alert">{error.message}</div>}
      </section>

      <section className="cm-section" aria-labelledby="bulk-invite-heading">
        <h3 id="bulk-invite-heading">Bulk Invite Candidates</h3>
        <form onSubmit={handleBulkInvite}>
          <div className="bulk-invite-options">
            <div className="bulk-option">
              <label htmlFor="bulk-emails">Paste Emails</label>
              <textarea
                id="bulk-emails"
                value={bulkEmails}
                onChange={(e) => { setBulkEmails(e.target.value); setError(null); }}
                placeholder="john@example.com, jane@example.com"
                rows={5}
                className="bulk-invite-textarea"
                disabled={isBulkInviting}
                aria-describedby="bulk-format-instructions"
              ></textarea>
               <p id="bulk-format-instructions" className="sr-only">Enter multiple emails separated by commas, spaces, or new lines.</p>
            </div>
            <div className="divider-or" aria-hidden="true">OR</div>
            <div className="bulk-option">
              <label htmlFor="csv-upload">Upload a CSV</label>
              <p className="upload-instructions" id="csv-instructions">Upload a single-column CSV file of email addresses.</p>
              <input 
                type="file" 
                id="csv-upload" 
                className="file-upload-input"
                accept=".csv, text/csv"
                ref={fileInputRef}
                onChange={() => setError(null)}
                disabled={isBulkInviting}
                aria-describedby="csv-instructions"
              />
              <label htmlFor="csv-upload" className={`file-upload-label ${isBulkInviting ? 'disabled' : ''}`}>
                Choose File
              </label>
            </div>
          </div>
          <button type="submit" className="bulk-invite-button" disabled={isBulkInviting}>
            {isBulkInviting ? <span className="spinner" aria-label="Sending invites"></span> : `Send ${bulkEmails.split(/[,\s\n]+/).filter(e => e).length || 'Bulk'} Invites`}
          </button>
        </form>
        {error && error.field === 'bulk' && <div className="error-display" role="alert">{error.message}</div>}
      </section>

      <section className="cm-section" aria-labelledby="pipeline-heading">
        <h3 id="pipeline-heading">Candidate Pipeline</h3>
        <div className="filter-controls">
            <div className="filter-dropdown-container">
                <label htmlFor="status-filter">Filter by Status:</label>
                <select
                    id="status-filter"
                    className="status-filter-dropdown"
                    value={activeFilter}
                    onChange={(e) => setActiveFilter(e.target.value)}
                >
                    {filterOptions.map(option => (
                        <option key={option} value={option}>
                            {option}
                        </option>
                    ))}
                </select>
            </div>
            <div className="actions-container">
                <div className="search-bar-container">
                    <label htmlFor="candidate-search" className="sr-only">Search by email or name</label>
                    <input
                        type="search"
                        id="candidate-search"
                        placeholder="Search by email or name..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="candidate-search-input"
                    />
                </div>
                <button onClick={handleExportCSV} className="export-button">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16" height="16" aria-hidden="true"><path d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z"></path></svg>
                    Export CSV
                </button>
            </div>
        </div>
        <div className="candidate-list-container">
          <div className="list-header" role="row">
            <button 
                className="sortable-header col-email" 
                onClick={() => requestSort('email')}
                aria-sort={sortConfig.key === 'email' ? `${sortConfig.direction}` : 'none'}
            >
              Candidate Email {getSortIndicator('email')}
            </button>
            <div className="header-item col-progress">Progress</div>
            <button 
                className="sortable-header col-score"
                onClick={() => requestSort('score')}
                aria-sort={sortConfig.key === 'score' ? `${sortConfig.direction}` : 'none'}
            >
              Score {getSortIndicator('score')}
            </button>
            <button 
                className="sortable-header col-status"
                onClick={() => requestSort('status')}
                aria-sort={sortConfig.key === 'status' ? `${sortConfig.direction}` : 'none'}
            >
              Status {getSortIndicator('status')}
            </button>
            <div className="header-item col-actions">Actions</div>
          </div>
          <div className="list-body" aria-live="polite">
            {displayCandidates.length > 0 ? (
                displayCandidates.map(candidate => {
                    const progressProps = getProgressProps(candidate.status);
                    const latestScore = candidate.interviewHistory[0]?.score;
                    return (
                        <button 
                            key={candidate.id} 
                            className="candidate-item" 
                            onClick={() => navigate(`#/candidates/${candidate.id}`)}
                            aria-label={`View profile for ${candidate.email}, status: ${candidate.status}`}
                        >
                            <span className="col-email">{candidate.email}</span>
                            <div className="col-progress">
                                <div className="progress-bar-container" title={`${progressProps.percentage}% Complete`}>
                                    <div className={`progress-bar-fill ${progressProps.colorClass}`} style={{ width: `${progressProps.percentage}%` }}></div>
                                </div>
                            </div>
                            <span className="col-score">{latestScore ?? 'N/A'}</span>
                            <div className="col-status">
                                <span className={`status-badge ${getStatusClass(candidate.status)}`}>
                                    {candidate.status}
                                </span>
                            </div>
                            <div className="col-actions">
                                <button
                                    className="delete-button"
                                    onClick={(e) => {
                                        e.stopPropagation(); // Prevent navigating to profile
                                        handleDeleteCandidate(candidate.id);
                                    }}
                                    aria-label={`Delete candidate ${candidate.email}`}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18" aria-hidden="true"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"></path></svg>
                                </button>
                            </div>
                        </button>
                    )
                })
            ) : (
                <div className="no-candidates-found">
                    <p>No candidates match your criteria.</p>
                </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};